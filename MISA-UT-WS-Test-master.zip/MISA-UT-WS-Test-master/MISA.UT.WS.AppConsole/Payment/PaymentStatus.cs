﻿namespace MISA.UT.WS.AppConsole.Payment
{
    public class PaymentResult
    {
        public string TransactionId { set; get; }
        public bool Status { get;  set; }
    }
}