﻿namespace MISA.UT.WS.AppConsole.Email
{
    public class EmailDto
    {
        public string To { get;  set; }
        public string From { get;  set; }
        public string Subject { set; get; }
        public string Content{ get; set; }
    }
}