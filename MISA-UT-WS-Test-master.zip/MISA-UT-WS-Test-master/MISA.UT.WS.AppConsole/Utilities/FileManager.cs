﻿namespace MISA.UT.WS.AppConsole.Utilities
{
    public class FileManager : IFileManager
    {
        public string ReadAllText(string path)
        {
            return System.IO.File.ReadAllText(path);
        }
    }
}
