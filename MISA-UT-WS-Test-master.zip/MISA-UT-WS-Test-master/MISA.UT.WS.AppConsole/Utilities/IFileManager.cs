﻿namespace MISA.UT.WS.AppConsole.Utilities
{
    public interface IFileManager
    {
        string ReadAllText(string path);
    }
}
