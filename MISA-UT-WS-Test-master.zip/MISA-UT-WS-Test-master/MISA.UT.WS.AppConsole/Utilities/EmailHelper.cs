﻿using MISA.UT.WS.AppConsole.Orders;
using MISA.UT.WS.AppConsole.Sessions;
using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.UT.WS.AppConsole.Utilities
{
    public class EmailHelper
    {
        private static IFileManager _fileManager = null;
        public static string CreateOrderContent(UserInfo userInfo, Order order,IFileManager fileManager = null)
        {
            _fileManager = _fileManager ?? new FileManager();
            string templateContent = _fileManager.ReadAllText(@"OrderEmailTemplate.txt");
            templateContent = templateContent.Replace("##Name##", userInfo.Name);
            templateContent = templateContent.Replace("##OrderId##", order.Id.ToString());
            return templateContent;
        }
    }
}
