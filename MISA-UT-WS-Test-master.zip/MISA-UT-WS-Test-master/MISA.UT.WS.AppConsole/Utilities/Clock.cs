﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.UT.WS.AppConsole.Utilities
{
    public class Clock : IClock
    {
        public DateTime Now => DateTime.Now;
    }
}
