﻿namespace MISA.UT.WS.AppConsole.Products
{
    public interface IProductRepository
    {
    }
}