﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.UT.WS.AppConsole.Products
{
    public class ProductRepository: IProductRepository
    {
    }
}
