﻿using MISA.UT.WS.AppConsole.Orders;
using System;
using System.Collections.Generic;

namespace MISA.UT.WS.AppConsole.UnitTest.Orders
{
    internal class BuildOrder
    {

        private Order _order;
        private static BuildOrder _instant { set; get; }
        private BuildOrder()
        {
            _order = new Order() { Details = new List<Order.Detail>() };
        }
        internal static BuildOrder Instant()
        {
            _instant = _instant ?? new BuildOrder();
            return _instant;
        }

        internal BuildOrder AddDetail(Order.Detail detail)
        {
            _order.Details.Add(detail);
            return _instant;
        }
        internal BuildOrder InitDefaultValue()
        {
            _order = new Order()
            {

                Details = new List<Order.Detail>()
                {
                    { new Order.Detail()
                    {
                        ProductID = new System.Guid("3246ee40-912e-4419-a072-e2ec4e637464")
                    } },
                    { new Order.Detail()
                    {
                        ProductID = new System.Guid("27642c97-17b5-4a67-a14f-a9cd4e71c66d")
                    } }
                }
            };
            return _instant;
        }
        internal Order Build()
        {
            return _order;
        }
    }
}