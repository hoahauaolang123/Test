using Microsoft.Extensions.FileProviders.Embedded;
using Microsoft.Extensions.Logging;
using MISA.UT.WS.AppConsole.Email;
using MISA.UT.WS.AppConsole.Orders;
using MISA.UT.WS.AppConsole.Payment;
using MISA.UT.WS.AppConsole.Products;
using MISA.UT.WS.AppConsole.Sessions;
using MISA.UT.WS.AppConsole.Utilities;
using MISA.UT.WS.Tools;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Threading.Tasks;
using VerifyNUnit;
using VerifyTests;
using static MISA.UT.WS.AppConsole.Orders.Order;

namespace MISA.UT.WS.AppConsole.UnitTest.Orders
{
    public class OrderServiceTest
    {
        private IOrderRepository _orderRepository;
        private IProductService _productService;
        private IPaymentService _paymentService;
        private ISessionService _sessionService;
        private OrderService _orderService;
        private ILogger<OrderService> _logger;
        private IFileManager _fileManager;
        private MISAEmail _email;
        private PrivateObject _poSendEmail;
        private PrivateObject _poOrderService;
        private IClock _clock;
        [SetUp]
        public void Setup()
        {
            VerifierSettings.DerivePathInfo((
                sourceFile,
                projectDirectory,
                type,
                method) => new PathInfo(
                    directory: Path.Combine(
                    projectDirectory,
                    "Snapshots"),
                    typeName: type.Name,
                    methodName: method.Name));
            VerifyNSubstitute.Enable();
            _orderRepository = Substitute.For<IOrderRepository>();
            _productService = Substitute.For<IProductService>();
            _paymentService = Substitute.For<IPaymentService>();
            _sessionService = Substitute.For<ISessionService>();
            _logger = Substitute.For<ILogger<OrderService>>();
            _clock = Substitute.For<IClock>();
            _orderService = Substitute.For<OrderService>(
                _orderRepository,
                _productService,
                _paymentService,
                _sessionService,
                _logger,
                _clock);

            _fileManager = Substitute.For<IFileManager>();
            var ptEmail = new PrivateType(typeof(EmailHelper));
            ptEmail.SetStaticField("_fileManager", _fileManager);
            //_poSendEmail = new PrivateObject(_email, ptEmail);

            
            _email = Substitute.For<MISAEmail>();
            _poOrderService = new PrivateObject(_orderService, new PrivateType(typeof(OrderService)));
            _poOrderService.SetField("_email", _email);
        }

        [Test]
        public async Task Create_OrderDetailInvalid_ThrowBusinessException()
        {
            //Arrange
            var orderInvalid = new Order()
            {

                Details = new List<Order.Detail>()
                {
                    { new Order.Detail()
                    {
                        ProductID = new System.Guid("3246ee40-912e-4419-a072-e2ec4e637464")
                    } },
                    { new Order.Detail()
                    {
                        ProductID = new System.Guid("27642c97-17b5-4a67-a14f-a9cd4e71c66d")
                    } }
                }
            };
            _productService.IsValid(Arg.Any<Order.Detail>()).Returns(false);

            //Act
            var result = await Verifier.Throws(() => _orderService.Create(orderInvalid)).IgnoreStackTrace();

            //Assert
            Assert.NotNull(result);
        }

        [Test]
        public async Task Create_UserNotLoggedIn_ThrowBusinessException()
        {
            //Arrange
            var order = BuildOrder.Instant()
                .Build();
            _productService.IsValid(Arg.Any<Order.Detail>()).Returns(true);
            _sessionService.IsLoggedIn().Returns(false);
            //Act
            var result = await Verifier.Throws(() => _orderService.Create(order)).IgnoreStackTrace();

            //Assert
            Assert.NotNull(result);
        }

        [Test]
        public async Task Create_CreateOrderFail_ThrowBussinessException()
        {
            //Arrange
            var dateNow = new DateTime(2022, 8, 22);
            var orderId = Guid.Empty;
            var order = BuildOrder.Instant()
                .InitDefaultValue()
                .Build();
            _productService.IsValid(Arg.Any<Order.Detail>()).Returns(true);
            _sessionService.IsLoggedIn().Returns(true);
            _orderRepository.Create(Arg.Any<Order>()).Returns(orderId);
            _clock.Now.Returns(dateNow);
            //Act
            var result = await Verifier.Throws(() => _orderService.Create(order)).UseMethodName("Create_CreateOrderFail_ThrowBussinessException").IgnoreStackTrace();

            //Assert

            Assert.NotNull(result);
            await Verifier.Verify(_logger.ReceivedCalls()).UseMethodName("Create_CreateOrderFail_ThrowBussinessException_Logger");

        }

        static object[] PaymentResultCase =
        {
            new object[]{1,null},
            new object[]{2,new PaymentResult() { Status=false}}
        };
       

        [Test]
        [TestCaseSource(nameof(PaymentResultCase))]
        public async Task Create_CreatePaymentFail_ThrowBusinessException(int countCase, PaymentResult paymentResult)
        {
            //Arrange
            var order = BuildOrder
                .Instant()
                .InitDefaultValue()
                .Build();
            var orderId = new Guid("9f159597-6fc1-45f3-b8dd-04c648d39689");
            var dateNow = new DateTime(2022, 8, 22);
            _productService.IsValid(Arg.Any<Order.Detail>()).Returns(true);
            _sessionService.IsLoggedIn().Returns(true);
            _orderRepository.Create(Arg.Any<Order>()).Returns(orderId);
            _clock.Now.Returns(dateNow);
            Guid cardId = new Guid("0b3f554c-4de6-4746-9881-44b8f3f1146b");
            order.CardId = cardId;
            var userInfo = new UserInfo()
            {
                Cards = new List<UserInfo.CardInfo>()
                {
                    {new UserInfo.CardInfo()
                    {
                        CardId = cardId,
                        AccNumber = "123456789",
                        CardNumber = "987654321"

                    } }
                }
            };
            _sessionService.GetCurrentUser().Returns(userInfo);
            _paymentService.Create(Arg.Any<PaymentDto>()).Returns(paymentResult);
            //Act
            var result = await Verifier.Throws(() => _orderService.Create(order))
                .UseParameters(countCase)
                .UseMethodName("Create_CreatePaymentFail_ThrowBusinessException")
                .IgnoreStackTrace()
                .UseParameters(countCase);

            //Assert
            Assert.NotNull(result);

            await Verifier.Verify(_logger.ReceivedCalls()).UseMethodName("Create_CreatePaymentFail_ThrowBusinessException_logger").
                UseParameters(countCase);
            await Verifier.Verify(_orderRepository.ReceivedCalls())
                .DontScrubGuids()
                .DontScrubDateTimes()
                .UseMethodName("Create_CreatePaymentFail_ThrowBusinessExceptionorderRepository")
                .UseParameters(countCase);
        }

        [Test]
        public Task Create_CreatePaymentSuccess_OrderId()
        {
            //Arrange
            var order = BuildOrder
                .Instant()
                .InitDefaultValue()
                .Build();
            var orderId = new Guid("9f159597-6fc1-45f3-b8dd-04c648d39689");
            var dateNow = new DateTime(2022, 8, 22);
            _productService.IsValid(Arg.Any<Order.Detail>()).Returns(true);
            _sessionService.IsLoggedIn().Returns(true);
            _orderRepository.Create(Arg.Any<Order>()).Returns(orderId);
            _clock.Now.Returns(dateNow);
            Guid cardId = new Guid("0b3f554c-4de6-4746-9881-44b8f3f1146b");
            order.CardId = cardId;
            var userInfo = new UserInfo()
            {
                Name= "Nguyen Van Nam",
                Email = "customer01@gmail.com",
                Cards = new List<UserInfo.CardInfo>()
                {
                    {new UserInfo.CardInfo()
                    {
                        CardId = cardId,
                        AccNumber = "123456789",
                        CardNumber = "987654321"

                    } }
                }
            };
            _sessionService.GetCurrentUser().Returns(userInfo);
            var paymentResult = new PaymentResult() { Status = true, TransactionId = "tran220822123456" };
            _paymentService.Create(Arg.Any<PaymentDto>()).Returns(paymentResult);

            _fileManager.ReadAllText(Arg.Any<string>()).Returns("Send to customer ##Name## with orderId ##OrderId##");
            _orderService.When(m => m.SendEmail(Arg.Any<Order>())).CallBase();

            //Act
            var result = _orderService.Create(order);

            //Assert
            Assert.That(result, Is.EqualTo(orderId));
            return Task.WhenAll(Verifier.Verify(_orderRepository.ReceivedCalls())
                .UseMethodName("Create_CreatePaymentSuccess_OrderId_OrderRepository")
                .DontScrubDateTimes()
                .DontScrubGuids(),
                Verifier.Verify(_fileManager.ReceivedCalls())
                .UseMethodName("Create_CreatePaymentSuccess_OrderId_FileManager")
                .DontScrubDateTimes()
            .DontScrubGuids(),
                 Verifier.Verify(_email.ReceivedCalls())
                .UseMethodName("Create_CreatePaymentSuccess_OrderId_SendEmail")
                .DontScrubDateTimes()
                .DontScrubGuids(),
                Verifier.Verify(_orderService.ReceivedCalls())
                .UseMethodName("Create_CreatePaymentSuccess_OrderId_Orderservice")
                .DontScrubDateTimes()
                .DontScrubGuids()
                );

        }

        [Test]
        public Task Create_SendEmailFail_OrderId()
        {
            //Arrange
            var order = BuildOrder
                .Instant()
                .InitDefaultValue()
                .Build();
            var orderId = new Guid("9f159597-6fc1-45f3-b8dd-04c648d39689");
            var dateNow = new DateTime(2022, 8, 22);
            _productService.IsValid(Arg.Any<Order.Detail>()).Returns(true);
            _sessionService.IsLoggedIn().Returns(true);
            _orderRepository.Create(Arg.Any<Order>()).Returns(orderId);
            _clock.Now.Returns(dateNow);
            Guid cardId = new Guid("0b3f554c-4de6-4746-9881-44b8f3f1146b");
            order.CardId = cardId;
            var userInfo = new UserInfo()
            {
                Cards = new List<UserInfo.CardInfo>()
                {
                    {new UserInfo.CardInfo()
                    {
                        CardId = cardId,
                        AccNumber = "123456789",
                        CardNumber = "987654321"

                    } }
                }
            };
            _sessionService.GetCurrentUser().Returns(userInfo);
            var paymentResult = new PaymentResult() { Status = true, TransactionId = "tran220822123456" };
            _paymentService.Create(Arg.Any<PaymentDto>()).Returns(paymentResult);
            _orderService.When(m => m.SendEmail(Arg.Any<Order>())).Do(m => { throw new Exception("Connect to service timeout!"); });

            //Act
            var result = _orderService.Create(order);

            //Assert
            Assert.That(result, Is.EqualTo(orderId));
            return Task.WhenAll(Verifier.Verify(_orderRepository.ReceivedCalls())
                .UseMethodName("Create_SendEmailFail_OrderId_OrderRepository")
                .DontScrubDateTimes()
                .DontScrubGuids(),
                Verifier.Verify(_orderService.ReceivedCalls())
                .UseMethodName("Create_SendEmailFail_OrderId_Orderservice")
                .DontScrubDateTimes()
                .DontScrubGuids(),
                Verifier.Verify(_logger.ReceivedCalls())
                .UseMethodName("Create_SendEmailFail_OrderId_Logger")
                .DontScrubDateTimes()
                .DontScrubGuids()
                .IgnoreStackTrace()
                );
        }

    }
}